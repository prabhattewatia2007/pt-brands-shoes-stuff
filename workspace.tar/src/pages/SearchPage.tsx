import { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search as SearchIcon } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { products } from '../data/products';

export default function SearchPage() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';

  const results = useMemo(() => {
    if (!query) return [];
    const q = query.toLowerCase();
    return products.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.brand.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q)
    );
  }, [query]);

  return (
    <div className="min-h-screen pt-20 lg:pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center gap-3 mb-2">
            <SearchIcon size={24} className="text-orange-500" />
            <h1 className="text-3xl font-bold text-white">Search Results</h1>
          </div>
          <p className="text-gray-400 mb-8">
            {query ? `${results.length} results for "${query}"` : 'Enter a search term to find products'}
          </p>
        </motion.div>

        {results.length === 0 && query ? (
          <div className="text-center py-20">
            <SearchIcon size={48} className="text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400 text-lg">No products found for "{query}"</p>
            <p className="text-gray-600 text-sm mt-2">Try different keywords or browse our collections</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {results.map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
