import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { brands, products } from '../data/products';

export default function BrandsPage() {
  return (
    <div className="min-h-screen pt-20 lg:pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-black text-white mb-3">OUR BRANDS</h1>
          <p className="text-gray-400 max-w-lg mx-auto">Explore footwear collections from the world's most popular brands.</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {brands.map((brand, i) => {
            const brandProducts = products.filter(p => p.brand === brand.name);
            return (
              <motion.div
                key={brand.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <Link
                  to={`/brands/${brand.name.toLowerCase().replace(' ', '-')}`}
                  className="group block bg-[#141414] border border-[#222] rounded-2xl overflow-hidden hover:border-orange-500/30 transition-all duration-300 card-hover"
                >
                  {/* Brand Header */}
                  <div className="relative h-40 overflow-hidden" style={{ background: `linear-gradient(135deg, ${brand.accent}22, ${brand.accent}05)` }}>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div
                        className="w-20 h-20 rounded-full flex items-center justify-center text-white font-black text-3xl"
                        style={{ background: `linear-gradient(135deg, ${brand.accent}44, ${brand.accent}11)`, border: `2px solid ${brand.accent}44` }}
                      >
                        {brand.name.charAt(0)}
                      </div>
                    </div>
                    <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                      <span className="flex items-center gap-1 text-orange-500 text-sm font-medium">
                        Explore <ArrowRight size={14} />
                      </span>
                    </div>
                  </div>

                  {/* Brand Info */}
                  <div className="p-6">
                    <h2 className="text-xl font-bold text-white group-hover:text-orange-500 transition-colors">{brand.name}</h2>
                    <p className="text-orange-500/70 text-sm italic mb-2">"{brand.tagline}"</p>
                    <p className="text-gray-400 text-sm mb-4">{brand.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {brand.categories.map(cat => (
                        <span key={cat} className="px-2 py-1 bg-[#1a1a1a] border border-[#333] rounded-md text-gray-400 text-xs">
                          {cat}
                        </span>
                      ))}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-500 text-sm">{brandProducts.length} products</span>
                      <span className="text-orange-500 text-sm font-medium flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        Shop Now <ArrowRight size={14} />
                      </span>
                    </div>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
