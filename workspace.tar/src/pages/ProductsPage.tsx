import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Filter, X, SlidersHorizontal } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { products, brands } from '../data/products';

export default function ProductsPage() {
  const [searchParams] = useSearchParams();
  const [showFilters, setShowFilters] = useState(false);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [selectedGender, setSelectedGender] = useState<string>(searchParams.get('gender') || '');
  const [selectedCategory, setSelectedCategory] = useState<string>(searchParams.get('category') || '');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500]);
  const [sortBy, setSortBy] = useState('featured');
  const [showNewOnly] = useState(searchParams.get('new') === 'true');
  const [showSaleOnly] = useState(searchParams.get('sale') === 'true');

  const allCategories = useMemo(() => {
    const cats = new Set<string>();
    products.forEach(p => cats.add(p.category));
    return Array.from(cats);
  }, []);

  const filteredProducts = useMemo(() => {
    let result = [...products];

    if (selectedBrands.length > 0) {
      result = result.filter(p => selectedBrands.includes(p.brand));
    }
    if (selectedGender) {
      result = result.filter(p => p.gender === selectedGender || p.gender === 'unisex');
    }
    if (selectedCategory) {
      result = result.filter(p => p.category === selectedCategory);
    }
    result = result.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);
    if (showNewOnly) result = result.filter(p => p.isNew);
    if (showSaleOnly) result = result.filter(p => p.isSale);

    switch (sortBy) {
      case 'price-low': result.sort((a, b) => a.price - b.price); break;
      case 'price-high': result.sort((a, b) => b.price - a.price); break;
      case 'rating': result.sort((a, b) => b.rating - a.rating); break;
      case 'newest': result.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0)); break;
    }

    return result;
  }, [selectedBrands, selectedGender, selectedCategory, priceRange, sortBy, showNewOnly, showSaleOnly]);

  const toggleBrand = (brand: string) => {
    setSelectedBrands(prev =>
      prev.includes(brand) ? prev.filter(b => b !== brand) : [...prev, brand]
    );
  };

  const clearFilters = () => {
    setSelectedBrands([]);
    setSelectedGender('');
    setSelectedCategory('');
    setPriceRange([0, 500]);
  };

  const activeFilters = selectedBrands.length + (selectedGender ? 1 : 0) + (selectedCategory ? 1 : 0);

  return (
    <div className="min-h-screen pt-20 lg:pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            {showSaleOnly ? 'Sale Items' : showNewOnly ? 'New Arrivals' : selectedGender ? `${selectedGender.charAt(0).toUpperCase() + selectedGender.slice(1)}'s Shoes` : 'All Shoes'}
          </h1>
          <p className="text-gray-400">{filteredProducts.length} products found</p>
        </motion.div>

        {/* Toolbar */}
        <div className="flex items-center justify-between mb-6 gap-4">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2 bg-[#141414] border border-[#333] rounded-lg px-4 py-2.5 text-gray-300 hover:border-orange-500 transition-colors"
          >
            <SlidersHorizontal size={16} />
            <span className="text-sm font-medium">Filters</span>
            {activeFilters > 0 && (
              <span className="w-5 h-5 bg-orange-500 rounded-full text-[10px] text-white flex items-center justify-center">
                {activeFilters}
              </span>
            )}
          </button>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="bg-[#141414] border border-[#333] rounded-lg px-4 py-2.5 text-gray-300 text-sm focus:outline-none focus:border-orange-500"
          >
            <option value="featured">Featured</option>
            <option value="newest">Newest</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="rating">Highest Rated</option>
          </select>
        </div>

        <div className="flex gap-8">
          {/* Filters Sidebar */}
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="w-64 flex-shrink-0 hidden lg:block"
            >
              <div className="bg-[#141414] border border-[#222] rounded-2xl p-5 sticky top-24 space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-white font-semibold flex items-center gap-2">
                    <Filter size={16} className="text-orange-500" /> Filters
                  </h3>
                  {activeFilters > 0 && (
                    <button onClick={clearFilters} className="text-orange-500 text-xs hover:underline">Clear all</button>
                  )}
                </div>

                {/* Brand Filter */}
                <div>
                  <h4 className="text-gray-300 text-sm font-medium mb-3">Brand</h4>
                  <div className="space-y-2">
                    {brands.map(brand => (
                      <label key={brand.name} className="flex items-center gap-2 cursor-pointer group">
                        <input
                          type="checkbox"
                          checked={selectedBrands.includes(brand.name)}
                          onChange={() => toggleBrand(brand.name)}
                          className="w-4 h-4 rounded border-[#333] bg-[#1a1a1a] text-orange-500 focus:ring-orange-500"
                        />
                        <span className="text-gray-400 text-sm group-hover:text-white transition-colors">{brand.name}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Gender Filter */}
                <div>
                  <h4 className="text-gray-300 text-sm font-medium mb-3">Gender</h4>
                  <div className="flex flex-wrap gap-2">
                    {['men', 'women', 'unisex'].map(g => (
                      <button
                        key={g}
                        onClick={() => setSelectedGender(selectedGender === g ? '' : g)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                          selectedGender === g
                            ? 'bg-orange-500 text-white'
                            : 'bg-[#1a1a1a] text-gray-400 border border-[#333] hover:border-orange-500'
                        }`}
                      >
                        {g.charAt(0).toUpperCase() + g.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Category Filter */}
                <div>
                  <h4 className="text-gray-300 text-sm font-medium mb-3">Category</h4>
                  <div className="flex flex-wrap gap-2">
                    {allCategories.map(cat => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(selectedCategory === cat ? '' : cat)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                          selectedCategory === cat
                            ? 'bg-orange-500 text-white'
                            : 'bg-[#1a1a1a] text-gray-400 border border-[#333] hover:border-orange-500'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Price Range */}
                <div>
                  <h4 className="text-gray-300 text-sm font-medium mb-3">Price Range</h4>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={priceRange[0]}
                      onChange={(e) => setPriceRange([Number(e.target.value), priceRange[1]])}
                      className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-orange-500"
                      placeholder="Min"
                    />
                    <span className="text-gray-500">-</span>
                    <input
                      type="number"
                      value={priceRange[1]}
                      onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
                      className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-orange-500"
                      placeholder="Max"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Product Grid */}
          <div className="flex-1">
            {filteredProducts.length === 0 ? (
              <div className="text-center py-20">
                <Filter size={48} className="text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400 text-lg font-medium">No products found</p>
                <p className="text-gray-600 text-sm mt-1">Try adjusting your filters</p>
                <button onClick={clearFilters} className="mt-4 btn-outline text-sm">
                  Clear Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
                {filteredProducts.map((product, i) => (
                  <ProductCard key={product.id} product={product} index={i} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
