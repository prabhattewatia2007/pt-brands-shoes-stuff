import { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Package, Heart, MapPin, Settings, LogIn, Mail, Lock } from 'lucide-react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { login, logout } from '../store/authSlice';
import { Link } from 'react-router-dom';

export default function AccountPage() {
  const dispatch = useDispatch();
  const { user, isAuthenticated } = useSelector((state: RootState) => state.auth);
  const [activeTab, setActiveTab] = useState('profile');
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [registerForm, setRegisterForm] = useState({ name: '', email: '', password: '' });
  const [isRegister, setIsRegister] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch(login({
      id: '1',
      name: loginForm.email.split('@')[0] || 'User',
      email: loginForm.email,
      isAdmin: loginForm.email === 'admin@ptbrands.com',
    }));
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch(login({
      id: '1',
      name: registerForm.name,
      email: registerForm.email,
      isAdmin: false,
    }));
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen pt-20 lg:pt-24 pb-16 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <div className="bg-[#141414] border border-[#222] rounded-2xl p-8">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-orange-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <LogIn size={28} className="text-orange-500" />
              </div>
              <h1 className="text-2xl font-bold text-white">{isRegister ? 'Create Account' : 'Welcome Back'}</h1>
              <p className="text-gray-400 text-sm mt-1">
                {isRegister ? 'Join PT Brands community' : 'Sign in to your account'}
              </p>
            </div>

            {isRegister ? (
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="relative">
                  <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    type="text"
                    placeholder="Full Name"
                    value={registerForm.name}
                    onChange={(e) => setRegisterForm({ ...registerForm, name: e.target.value })}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
                  />
                </div>
                <div className="relative">
                  <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    type="email"
                    placeholder="Email Address"
                    value={registerForm.email}
                    onChange={(e) => setRegisterForm({ ...registerForm, email: e.target.value })}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
                  />
                </div>
                <div className="relative">
                  <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    type="password"
                    placeholder="Password"
                    value={registerForm.password}
                    onChange={(e) => setRegisterForm({ ...registerForm, password: e.target.value })}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
                  />
                </div>
                <button type="submit" className="w-full btn-primary">Create Account</button>
              </form>
            ) : (
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="relative">
                  <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    type="email"
                    placeholder="Email Address"
                    value={loginForm.email}
                    onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
                  />
                </div>
                <div className="relative">
                  <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    type="password"
                    placeholder="Password"
                    value={loginForm.password}
                    onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
                  />
                </div>
                <button type="submit" className="w-full btn-primary">Sign In</button>
                <p className="text-center text-gray-500 text-sm">
                  Demo: use any email/password or admin@ptbrands.com for admin
                </p>
              </form>
            )}

            <div className="mt-6 text-center">
              <button
                onClick={() => setIsRegister(!isRegister)}
                className="text-orange-500 text-sm hover:underline"
              >
                {isRegister ? 'Already have an account? Sign In' : "Don't have an account? Register"}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'orders', label: 'My Orders', icon: Package },
    { id: 'wishlist', label: 'Wishlist', icon: Heart },
    { id: 'addresses', label: 'Addresses', icon: MapPin },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen pt-20 lg:pt-24 pb-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar */}
          <div className="md:w-64 flex-shrink-0">
            <div className="bg-[#141414] border border-[#222] rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                  {user?.name?.charAt(0).toUpperCase() || 'U'}
                </div>
                <div>
                  <p className="text-white font-medium">{user?.name || 'User'}</p>
                  <p className="text-gray-500 text-sm">{user?.email}</p>
                </div>
              </div>
              <nav className="space-y-1">
                {tabs.map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                      activeTab === tab.id
                        ? 'bg-orange-500/10 text-orange-500'
                        : 'text-gray-400 hover:text-white hover:bg-[#1a1a1a]'
                    }`}
                  >
                    <tab.icon size={16} />
                    {tab.label}
                  </button>
                ))}
                <button
                  onClick={() => dispatch(logout())}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-red-400 hover:bg-red-500/10 transition-all"
                >
                  <LogIn size={16} />
                  Logout
                </button>
              </nav>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-[#141414] border border-[#222] rounded-2xl p-6"
            >
              {activeTab === 'profile' && (
                <div>
                  <h2 className="text-xl font-bold text-white mb-6">My Profile</h2>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-gray-400 text-sm mb-1 block">Full Name</label>
                      <input
                        defaultValue={user?.name}
                        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white focus:outline-none focus:border-orange-500"
                      />
                    </div>
                    <div>
                      <label className="text-gray-400 text-sm mb-1 block">Email</label>
                      <input
                        defaultValue={user?.email}
                        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white focus:outline-none focus:border-orange-500"
                      />
                    </div>
                    <div>
                      <label className="text-gray-400 text-sm mb-1 block">Phone</label>
                      <input
                        placeholder="+1 (555) 123-4567"
                        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
                      />
                    </div>
                    <div>
                      <label className="text-gray-400 text-sm mb-1 block">Date of Birth</label>
                      <input
                        type="date"
                        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white focus:outline-none focus:border-orange-500"
                      />
                    </div>
                  </div>
                  <button className="btn-primary mt-6">Save Changes</button>
                </div>
              )}

              {activeTab === 'orders' && (
                <div>
                  <h2 className="text-xl font-bold text-white mb-6">My Orders</h2>
                  <div className="text-center py-12">
                    <Package size={48} className="text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400">No orders yet</p>
                    <Link to="/products" className="text-orange-500 text-sm hover:underline mt-2 inline-block">
                      Start Shopping
                    </Link>
                  </div>
                </div>
              )}

              {activeTab === 'wishlist' && (
                <div>
                  <h2 className="text-xl font-bold text-white mb-6">My Wishlist</h2>
                  <Link to="/wishlist" className="text-orange-500 hover:underline">
                    View Wishlist →
                  </Link>
                </div>
              )}

              {activeTab === 'addresses' && (
                <div>
                  <h2 className="text-xl font-bold text-white mb-6">Saved Addresses</h2>
                  <div className="text-center py-12">
                    <MapPin size={48} className="text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400">No saved addresses</p>
                    <button className="text-orange-500 text-sm hover:underline mt-2">
                      Add New Address
                    </button>
                  </div>
                </div>
              )}

              {activeTab === 'settings' && (
                <div>
                  <h2 className="text-xl font-bold text-white mb-6">Account Settings</h2>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-[#1a1a1a] rounded-xl">
                      <div>
                        <p className="text-white font-medium">Email Notifications</p>
                        <p className="text-gray-500 text-sm">Receive order updates and promotions</p>
                      </div>
                      <div className="w-12 h-6 bg-orange-500 rounded-full relative cursor-pointer">
                        <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full" />
                      </div>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-[#1a1a1a] rounded-xl">
                      <div>
                        <p className="text-white font-medium">Change Password</p>
                        <p className="text-gray-500 text-sm">Update your account password</p>
                      </div>
                      <button className="text-orange-500 text-sm hover:underline">Change</button>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-[#1a1a1a] rounded-xl">
                      <div>
                        <p className="text-white font-medium">Delete Account</p>
                        <p className="text-gray-500 text-sm">Permanently delete your account</p>
                      </div>
                      <button className="text-red-500 text-sm hover:underline">Delete</button>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
