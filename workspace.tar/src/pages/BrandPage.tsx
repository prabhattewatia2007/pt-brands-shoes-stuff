import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { products, brands } from '../data/products';

export default function BrandPage() {
  const { brandName } = useParams();
  const brandSlug = brandName?.replace(/-/g, ' ') || '';
  const brand = brands.find(b => b.name.toLowerCase() === brandSlug);
  const brandProducts = products.filter(p => p.brand.toLowerCase() === brandSlug);

  if (!brand) {
    return (
      <div className="min-h-screen pt-24 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-4">Brand Not Found</h1>
          <Link to="/" className="btn-primary">Go Home</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Brand Hero */}
      <section className="relative pt-20 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a0a] to-[#111]">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] rounded-full blur-[120px] opacity-20" style={{ background: brand.accent }} />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div
              className="w-20 h-20 mx-auto mb-6 rounded-full flex items-center justify-center text-white font-bold text-2xl"
              style={{ background: `linear-gradient(135deg, ${brand.accent}44, ${brand.accent}11)`, border: `2px solid ${brand.accent}66` }}
            >
              {brand.name.charAt(0)}
            </div>
            <h1 className="text-4xl md:text-6xl font-black text-white mb-3">{brand.name.toUpperCase()} COLLECTION</h1>
            <p className="text-gray-400 text-lg max-w-xl mx-auto mb-6">{brand.description}</p>
            <div className="flex flex-wrap justify-center gap-3">
              {brand.categories.map(cat => (
                <Link
                  key={cat}
                  to={`/products?category=${cat}&brand=${brand.name}`}
                  className="px-4 py-2 bg-[#141414] border border-[#333] rounded-full text-gray-300 text-sm hover:border-orange-500 hover:text-orange-500 transition-all"
                >
                  {cat}
                </Link>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Products */}
      <section className="py-12 pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-white">All {brand.name} Products</h2>
            <span className="text-gray-400">{brandProducts.length} items</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {brandProducts.map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* Other Brands */}
      <section className="py-16 bg-[#0a0a0a] border-t border-[#1a1a1a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-white mb-8">Explore Other Brands</h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {brands.filter(b => b.name !== brand.name).map(b => (
              <Link
                key={b.name}
                to={`/brands/${b.name.toLowerCase().replace(' ', '-')}`}
                className="group bg-[#141414] border border-[#222] rounded-xl p-4 text-center hover:border-orange-500/50 transition-all"
              >
                <div
                  className="w-12 h-12 mx-auto mb-3 rounded-full flex items-center justify-center text-white font-bold"
                  style={{ background: `${b.accent}22`, border: `1px solid ${b.accent}44` }}
                >
                  {b.name.charAt(0)}
                </div>
                <p className="text-white text-sm font-medium group-hover:text-orange-500 transition-colors">{b.name}</p>
                <p className="text-orange-500 text-xs mt-1 flex items-center justify-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  Shop <ArrowRight size={12} />
                </p>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
