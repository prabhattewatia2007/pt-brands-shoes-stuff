import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Zap, Shield, Truck, RotateCcw } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { products, brands } from '../data/products';

export default function Home() {
  const trendingProducts = products.filter(p => p.isNew).slice(0, 8);
  const saleProducts = products.filter(p => p.isSale).slice(0, 4);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[90vh] min-h-[600px] flex items-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a0a] via-[#111] to-[#0a0a0a]">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-orange-500/20 rounded-full blur-[120px]" />
            <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-orange-600/10 rounded-full blur-[120px]" />
          </div>
          <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(255,255,255,0.03) 1px, transparent 0)', backgroundSize: '40px 40px' }} />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <motion.p
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
                className="text-orange-500 font-semibold text-sm tracking-widest mb-4"
              >
                PREMIUM FOOTWEAR COLLECTION
              </motion.p>
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-5xl md:text-7xl font-black text-white leading-tight mb-6"
              >
                STEP INTO{' '}
                <span className="gradient-text">YOUR STYLE</span>
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="text-gray-400 text-lg md:text-xl mb-8 max-w-lg"
              >
                Discover premium footwear from the world's most popular brands. Nike, Adidas, Puma, and more.
              </motion.p>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="flex flex-wrap gap-4"
              >
                <Link to="/products" className="btn-primary flex items-center gap-2 text-base px-8 py-4">
                  SHOP NOW <ArrowRight size={18} />
                </Link>
                <Link to="/brands" className="btn-outline flex items-center gap-2 text-base px-8 py-4">
                  EXPLORE BRANDS
                </Link>
              </motion.div>

              {/* Stats */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.7 }}
                className="flex gap-8 mt-12"
              >
                {[
                  { value: '6+', label: 'Top Brands' },
                  { value: '500+', label: 'Products' },
                  { value: '50K+', label: 'Happy Customers' },
                ].map(stat => (
                  <div key={stat.label}>
                    <p className="text-2xl font-bold text-white">{stat.value}</p>
                    <p className="text-gray-500 text-sm">{stat.label}</p>
                  </div>
                ))}
              </motion.div>
            </motion.div>

            {/* Hero Image */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="hidden lg:block relative"
            >
              <div className="relative w-full aspect-square">
                <div className="absolute inset-0 bg-gradient-to-br from-orange-500/20 to-transparent rounded-full blur-[60px]" />
                <img
                  src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80"
                  alt="Premium Sneaker"
                  className="relative w-full h-full object-cover rounded-3xl shadow-2xl"
                />
                {/* Floating badge */}
                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{ repeat: Infinity, duration: 3 }}
                  className="absolute -bottom-4 -left-4 bg-[#141414] border border-[#333] rounded-2xl p-4 shadow-xl"
                >
                  <p className="text-orange-500 font-bold text-lg">50% OFF</p>
                  <p className="text-gray-400 text-xs">On Selected Items</p>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Bar */}
      <section className="bg-[#0f0f0f] border-y border-[#1a1a1a] py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: Truck, text: 'Free Shipping', sub: 'On orders over $100' },
              { icon: RotateCcw, text: 'Easy Returns', sub: '30-day return policy' },
              { icon: Shield, text: 'Secure Payment', sub: '100% secure checkout' },
              { icon: Zap, text: 'Fast Delivery', sub: 'Express shipping available' },
            ].map(({ icon: Icon, text, sub }) => (
              <div key={text} className="flex items-center gap-3 p-3">
                <div className="w-10 h-10 bg-orange-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Icon size={18} className="text-orange-500" />
                </div>
                <div>
                  <p className="text-white text-sm font-medium">{text}</p>
                  <p className="text-gray-500 text-xs">{sub}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Shop by Brand */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-3">SHOP BY BRAND</h2>
            <p className="text-gray-400 max-w-lg mx-auto">Explore footwear collections from your favorite brands.</p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {brands.map((brand, i) => (
              <motion.div
                key={brand.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Link
                  to={`/brands/${brand.name.toLowerCase().replace(' ', '-')}`}
                  className="group block bg-[#141414] border border-[#222] rounded-2xl p-6 text-center hover:border-orange-500/50 transition-all duration-300 card-hover"
                >
                  <div
                    className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center text-white font-bold text-lg"
                    style={{ background: `linear-gradient(135deg, ${brand.accent}33, ${brand.accent}11)`, border: `2px solid ${brand.accent}44` }}
                  >
                    {brand.name.charAt(0)}
                  </div>
                  <h3 className="text-white font-semibold text-sm group-hover:text-orange-500 transition-colors">{brand.name}</h3>
                  <p className="text-gray-500 text-xs mt-1">{brand.tagline}</p>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trending Now */}
      <section className="py-16 md:py-24 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex items-center justify-between mb-12"
          >
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">TRENDING NOW</h2>
              <p className="text-gray-400">The hottest picks this season</p>
            </div>
            <Link to="/products" className="hidden md:flex items-center gap-2 text-orange-500 hover:text-orange-400 font-medium transition-colors">
              View All <ArrowRight size={16} />
            </Link>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {trendingProducts.map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} />
            ))}
          </div>

          <div className="text-center mt-8 md:hidden">
            <Link to="/products" className="btn-outline inline-flex items-center gap-2">
              View All Products <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* Promo Banner */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative bg-gradient-to-r from-orange-600 to-orange-500 rounded-3xl p-8 md:p-16 overflow-hidden"
          >
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 right-0 w-64 h-64 bg-white rounded-full blur-[80px]" />
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-black rounded-full blur-[60px]" />
            </div>
            <div className="relative grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-3xl md:text-5xl font-black text-white mb-4">FIND YOUR PERFECT PAIR</h2>
                <p className="text-white/80 text-lg mb-6">Premium styles made for every step. Up to 50% off on selected items.</p>
                <Link to="/products?sale=true" className="inline-flex items-center gap-2 bg-white text-orange-600 px-8 py-4 rounded-xl font-bold hover:bg-gray-100 transition-colors">
                  SHOP COLLECTION <ArrowRight size={18} />
                </Link>
              </div>
              <div className="hidden md:block">
                <img
                  src="https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?w=600&q=80"
                  alt="Shoes collection"
                  className="w-full max-w-sm mx-auto rounded-2xl shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-500"
                />
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Sale Products */}
      <section className="py-16 md:py-24 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-3">
              <span className="text-red-500">SALE</span> - HOT DEALS
            </h2>
            <p className="text-gray-400">Grab these deals before they're gone!</p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {saleProducts.map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-3">SHOP BY CATEGORY</h2>
            <p className="text-gray-400">Find exactly what you're looking for</p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { name: "Men's Shoes", img: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&q=80', path: '/products?gender=men' },
              { name: "Women's Shoes", img: 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?w=400&q=80', path: '/products?gender=women' },
              { name: 'Running', img: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80', path: '/products?category=Running' },
              { name: 'Sneakers', img: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=400&q=80', path: '/products?category=Sneakers' },
            ].map((cat, i) => (
              <motion.div
                key={cat.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Link
                  to={cat.path}
                  className="group relative block aspect-[4/5] rounded-2xl overflow-hidden"
                >
                  <img
                    src={cat.img}
                    alt={cat.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  <div className="absolute bottom-4 left-4">
                    <h3 className="text-white font-bold text-lg">{cat.name}</h3>
                    <p className="text-orange-500 text-sm font-medium flex items-center gap-1 mt-1">
                      Shop Now <ArrowRight size={14} />
                    </p>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
