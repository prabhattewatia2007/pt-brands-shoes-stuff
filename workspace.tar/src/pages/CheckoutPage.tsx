import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MapPin, CreditCard, CheckCircle, Truck } from 'lucide-react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { clearCart } from '../store/cartSlice';

export default function CheckoutPage() {
  const dispatch = useDispatch();
  const items = useSelector((state: RootState) => state.cart.items);
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = subtotal > 100 ? 0 : 9.99;
  const total = subtotal + shipping;

  const [step, setStep] = useState(1);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [address, setAddress] = useState({ name: '', street: '', city: '', state: '', zip: '', phone: '' });
  const [payment, setPayment] = useState('cod');

  const steps = [
    { num: 1, label: 'Address', icon: MapPin },
    { num: 2, label: 'Payment', icon: CreditCard },
    { num: 3, label: 'Confirm', icon: CheckCircle },
  ];

  const handlePlaceOrder = () => {
    setOrderPlaced(true);
    dispatch(clearCart());
  };

  if (items.length === 0 && !orderPlaced) {
    return (
      <div className="min-h-screen pt-24 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-white mb-4">Your cart is empty</h1>
          <Link to="/products" className="btn-primary">Continue Shopping</Link>
        </div>
      </div>
    );
  }

  if (orderPlaced) {
    return (
      <div className="min-h-screen pt-24 flex items-center justify-center">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center max-w-md">
          <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle size={40} className="text-green-500" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-3">Order Placed Successfully!</h1>
          <p className="text-gray-400 mb-2">Thank you for your purchase.</p>
          <p className="text-gray-500 text-sm mb-8">Order #PT{Math.floor(Math.random() * 90000) + 10000}</p>
          <Link to="/products" className="btn-primary inline-flex items-center gap-2">
            Continue Shopping
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 lg:pt-24 pb-16">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-white mb-8">Checkout</h1>

        {/* Steps */}
        <div className="flex items-center justify-center mb-12">
          {steps.map((s, i) => (
            <div key={s.num} className="flex items-center">
              <div className={`flex items-center gap-2 px-4 py-2 rounded-full ${
                step >= s.num ? 'bg-orange-500/10 text-orange-500' : 'text-gray-500'
              }`}>
                <s.icon size={16} />
                <span className="text-sm font-medium hidden sm:inline">{s.label}</span>
              </div>
              {i < steps.length - 1 && (
                <div className={`w-12 h-0.5 mx-2 ${step > s.num ? 'bg-orange-500' : 'bg-[#333]'}`} />
              )}
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            {step === 1 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-[#141414] border border-[#222] rounded-2xl p-6">
                <h2 className="text-white font-bold text-lg mb-6 flex items-center gap-2">
                  <MapPin size={18} className="text-orange-500" /> Delivery Address
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input
                    placeholder="Full Name"
                    value={address.name}
                    onChange={(e) => setAddress({ ...address, name: e.target.value })}
                    className="bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
                  />
                  <input
                    placeholder="Phone Number"
                    value={address.phone}
                    onChange={(e) => setAddress({ ...address, phone: e.target.value })}
                    className="bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
                  />
                  <input
                    placeholder="Street Address"
                    value={address.street}
                    onChange={(e) => setAddress({ ...address, street: e.target.value })}
                    className="md:col-span-2 bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
                  />
                  <input
                    placeholder="City"
                    value={address.city}
                    onChange={(e) => setAddress({ ...address, city: e.target.value })}
                    className="bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      placeholder="State"
                      value={address.state}
                      onChange={(e) => setAddress({ ...address, state: e.target.value })}
                      className="bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
                    />
                    <input
                      placeholder="ZIP Code"
                      value={address.zip}
                      onChange={(e) => setAddress({ ...address, zip: e.target.value })}
                      className="bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
                    />
                  </div>
                </div>
                <button
                  onClick={() => setStep(2)}
                  className="btn-primary mt-6"
                >
                  Continue to Payment
                </button>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-[#141414] border border-[#222] rounded-2xl p-6">
                <h2 className="text-white font-bold text-lg mb-6 flex items-center gap-2">
                  <CreditCard size={18} className="text-orange-500" /> Payment Method
                </h2>
                <div className="space-y-3">
                  {[
                    { id: 'cod', label: 'Cash on Delivery', desc: 'Pay when you receive' },
                    { id: 'card', label: 'Credit/Debit Card', desc: 'Visa, Mastercard, Amex' },
                    { id: 'upi', label: 'UPI Payment', desc: 'Google Pay, PhonePe, Paytm' },
                  ].map(method => (
                    <label
                      key={method.id}
                      className={`flex items-center gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                        payment === method.id ? 'border-orange-500 bg-orange-500/5' : 'border-[#333] hover:border-[#444]'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        value={method.id}
                        checked={payment === method.id}
                        onChange={(e) => setPayment(e.target.value)}
                        className="text-orange-500 focus:ring-orange-500"
                      />
                      <div>
                        <p className="text-white font-medium">{method.label}</p>
                        <p className="text-gray-500 text-sm">{method.desc}</p>
                      </div>
                    </label>
                  ))}
                </div>
                <div className="flex gap-3 mt-6">
                  <button onClick={() => setStep(1)} className="btn-outline">Back</button>
                  <button onClick={() => setStep(3)} className="btn-primary">Review Order</button>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-[#141414] border border-[#222] rounded-2xl p-6">
                <h2 className="text-white font-bold text-lg mb-6 flex items-center gap-2">
                  <CheckCircle size={18} className="text-orange-500" /> Order Confirmation
                </h2>
                <div className="space-y-4 mb-6">
                  <div className="bg-[#1a1a1a] rounded-xl p-4">
                    <p className="text-gray-400 text-sm mb-1">Delivery Address</p>
                    <p className="text-white">{address.name || 'John Doe'}</p>
                    <p className="text-gray-400 text-sm">{address.street || '123 Main St'}, {address.city || 'New York'}, {address.state || 'NY'} {address.zip || '10001'}</p>
                  </div>
                  <div className="bg-[#1a1a1a] rounded-xl p-4">
                    <p className="text-gray-400 text-sm mb-1">Payment Method</p>
                    <p className="text-white">{payment === 'cod' ? 'Cash on Delivery' : payment === 'card' ? 'Credit/Debit Card' : 'UPI Payment'}</p>
                  </div>
                  <div className="bg-[#1a1a1a] rounded-xl p-4">
                    <p className="text-gray-400 text-sm mb-2">Items ({items.length})</p>
                    {items.map(item => (
                      <div key={item.id} className="flex justify-between text-sm py-1">
                        <span className="text-gray-300">{item.name} x{item.quantity}</span>
                        <span className="text-white">${(item.price * item.quantity).toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setStep(2)} className="btn-outline">Back</button>
                  <button onClick={handlePlaceOrder} className="btn-primary flex-1 flex items-center justify-center gap-2">
                    <Truck size={16} /> Place Order - ${total.toFixed(2)}
                  </button>
                </div>
              </motion.div>
            )}
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="bg-[#141414] border border-[#222] rounded-2xl p-6 sticky top-24">
              <h2 className="text-white font-bold text-lg mb-4">Order Summary</h2>
              <div className="space-y-3 mb-4 max-h-60 overflow-y-auto">
                {items.map(item => (
                  <div key={item.id} className="flex gap-3">
                    <img src={item.image} alt={item.name} className="w-12 h-12 rounded-lg object-cover" />
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm truncate">{item.name}</p>
                      <p className="text-gray-500 text-xs">Qty: {item.quantity}</p>
                    </div>
                    <span className="text-white text-sm font-medium">${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
              <div className="border-t border-[#333] pt-4 space-y-2">
                <div className="flex justify-between text-gray-400 text-sm">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-400 text-sm">
                  <span>Shipping</span>
                  <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between text-white font-bold text-lg pt-2 border-t border-[#333]">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
