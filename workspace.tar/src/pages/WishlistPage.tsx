import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, ShoppingBag, Trash2, ArrowRight } from 'lucide-react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { removeFromWishlist } from '../store/wishlistSlice';
import { addToCart } from '../store/cartSlice';

export default function WishlistPage() {
  const dispatch = useDispatch();
  const items = useSelector((state: RootState) => state.wishlist.items);

  const handleMoveToCart = (product: typeof items[0]) => {
    dispatch(addToCart({
      productId: product.id,
      name: product.name,
      brand: product.brand,
      price: product.price,
      image: product.image,
      size: product.sizes[Math.floor(product.sizes.length / 2)],
      color: product.colors[0],
      quantity: 1,
    }));
    dispatch(removeFromWishlist(product.id));
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen pt-24 flex items-center justify-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
          <Heart size={64} className="text-gray-600 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-white mb-2">Your Wishlist is Empty</h1>
          <p className="text-gray-400 mb-6">Save items you love for later.</p>
          <Link to="/products" className="btn-primary inline-flex items-center gap-2">
            Explore Products <ArrowRight size={16} />
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 lg:pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-3xl font-bold text-white mb-2">My Wishlist</h1>
          <p className="text-gray-400 mb-8">{items.length} items saved</p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
          {items.map((product, i) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-[#141414] border border-[#222] rounded-2xl overflow-hidden card-hover"
            >
              <Link to={`/product/${product.id}`}>
                <div className="aspect-square overflow-hidden">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                </div>
              </Link>
              <div className="p-4">
                <p className="text-orange-500 text-xs font-semibold uppercase">{product.brand}</p>
                <Link to={`/product/${product.id}`}>
                  <h3 className="text-white font-medium mt-1 hover:text-orange-400 transition-colors">{product.name}</h3>
                </Link>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-white font-bold">${product.price}</span>
                  {product.discount > 0 && (
                    <span className="text-gray-500 text-sm line-through">${product.originalPrice}</span>
                  )}
                </div>
                <div className="flex gap-2 mt-4">
                  <button
                    onClick={() => handleMoveToCart(product)}
                    className="flex-1 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg text-sm font-medium flex items-center justify-center gap-1 transition-colors"
                  >
                    <ShoppingBag size={14} /> Move to Cart
                  </button>
                  <button
                    onClick={() => dispatch(removeFromWishlist(product.id))}
                    className="w-10 h-10 bg-[#1a1a1a] border border-[#333] rounded-lg flex items-center justify-center text-gray-400 hover:text-red-500 hover:border-red-500/30 transition-all"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
