export interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  price: number;
  originalPrice: number;
  discount: number;
  rating: number;
  reviews: number;
  sizes: number[];
  colors: string[];
  gender: 'men' | 'women' | 'unisex';
  image: string;
  images: string[];
  description: string;
  isNew?: boolean;
  isSale?: boolean;
}

export const brands = [
  { name: 'Nike', tagline: 'Just Do It', color: '#111', accent: '#f97316', description: 'Discover performance-driven and stylish footwear for everyday movement.', categories: ['Running', 'Sneakers', 'Basketball', 'Lifestyle'] },
  { name: 'Adidas', tagline: 'Impossible Is Nothing', color: '#000', accent: '#3b82f6', description: 'Explore iconic sports-inspired footwear with modern street style.', categories: ['Running', 'Originals', 'Sneakers', 'Training'] },
  { name: 'Puma', tagline: 'Forever Faster', color: '#1a1a1a', accent: '#ef4444', description: 'Fresh and energetic footwear designed for active lifestyles.', categories: ['Sneakers', 'Running', 'Training', 'Lifestyle'] },
  { name: 'New Balance', tagline: 'Endurance in Every Step', color: '#0f172a', accent: '#22c55e', description: 'Premium comfort and timeless sneaker designs for everyday wear.', categories: ['Running', 'Walking', 'Lifestyle', 'Sneakers'] },
  { name: 'ASICS', tagline: 'Sound Mind, Sound Body', color: '#1e1b4b', accent: '#8b5cf6', description: 'Performance-oriented footwear designed for runners and athletes.', categories: ['Running', 'Training', 'Sports'] },
  { name: 'Converse', tagline: 'Be Yourself', color: '#18181b', accent: '#e11d48', description: 'Classic sneaker styles with timeless streetwear appeal.', categories: ['Classic Sneakers', 'Casual', 'High Tops', 'Low Tops'] },
];

const shoeImages = [
  'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80',
  'https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=600&q=80',
  'https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?w=600&q=80',
  'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=600&q=80',
  'https://images.unsplash.com/photo-1584735175315-9d5df23860e6?w=600&q=80',
  'https://images.unsplash.com/photo-1551107696-a4b0c5a0d9a2?w=600&q=80',
  'https://images.unsplash.com/photo-1539185441755-769473a23570?w=600&q=80',
  'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=600&q=80',
  'https://images.unsplash.com/photo-1560769629-975ec94e6a86?w=600&q=80',
  'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=600&q=80',
  'https://images.unsplash.com/photo-1605348532760-6753d2c43329?w=600&q=80',
  'https://images.unsplash.com/photo-1587563871167-1ee9c731aefb?w=600&q=80',
  'https://images.unsplash.com/photo-1597045566677-8cf032ed6634?w=600&q=80',
  'https://images.unsplash.com/photo-1579338559194-a162d19bf842?w=600&q=80',
  'https://images.unsplash.com/photo-1603808033192-082d61b8e1e3?w=600&q=80',
  'https://images.unsplash.com/photo-1620799140188-3b2a02fd9a77?w=600&q=80',
  'https://images.unsplash.com/photo-1556906781-9a412961c28c?w=600&q=80',
  'https://images.unsplash.com/photo-1491553895911-0055eca6402d?w=600&q=80',
  'https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=600&q=80',
  'https://images.unsplash.com/photo-1543508282-6319a3e2621f?w=600&q=80',
  'https://images.unsplash.com/photo-1515955656352-a1fa3ffcd111?w=600&q=80',
  'https://images.unsplash.com/photo-1565814636199-ae8133055c1c?w=600&q=80',
  'https://images.unsplash.com/photo-1495562569060-2eec283d3391?w=600&q=80',
  'https://images.unsplash.com/photo-1552346154-21d32810aba3?w=600&q=80',
];

const productNames: Record<string, string[]> = {
  Nike: ['Air Max 270', 'Air Force 1 Low', 'Zoom Pegasus 40', 'React Infinity Run', 'Dunk Low Retro', 'Air Jordan 1 Mid', 'Vaporfly Next%', 'Blazer Mid', 'Air Max 90', 'Free RN 5.0'],
  Adidas: ['Ultraboost 22', 'Stan Smith', 'Superstar', 'NMD R1', 'Forum Low', 'Gazelle', 'Samba OG', 'Continental 80', 'Yeezy Slide', 'Adizero Boston'],
  Puma: ['RS-X³', 'Suede Classic', 'Future Rider', 'Cali Star', 'Deviate Nitro', 'Rider FV', 'Slipstream', 'Velophasis', 'Suede XL', 'Disc Blaze'],
  'New Balance': ['574 Classic', '990v6', '327', '550', 'Fresh Foam 1080', '2002R', '530', '993', 'Fresh Foam X', '57/40'],
  ASICS: ['Gel-Kayano 30', 'Gel-Nimbus 25', 'Gel-Lyte III', 'GT-2000', 'Novablast 3', 'Gel-Quantum 360', 'MetaSpeed Sky', 'Gel-1130', 'Gel-Cumulus 25', 'Japan S'],
  Converse: ['Chuck Taylor All Star', 'Chuck 70 High', 'One Star', 'Jack Purcell', 'Chuck Taylor Low', 'Run Star Hike', 'All Star Pro BB', 'Chuck 70 Vintage', 'Star Player 76', 'Weapon CX'],
};

const categories: Record<string, string[]> = {
  Nike: ['Running', 'Sneakers', 'Basketball', 'Lifestyle'],
  Adidas: ['Running', 'Originals', 'Sneakers', 'Training'],
  Puma: ['Sneakers', 'Running', 'Training', 'Lifestyle'],
  'New Balance': ['Running', 'Walking', 'Lifestyle', 'Sneakers'],
  ASICS: ['Running', 'Training', 'Sports'],
  Converse: ['Classic Sneakers', 'Casual', 'High Tops', 'Low Tops'],
};

const colorOptions = ['Black', 'White', 'Red', 'Blue', 'Green', 'Grey', 'Navy', 'Orange', 'Pink', 'Beige'];
const sizeOptions = [6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5, 11, 11.5, 12];

function generateProducts(): Product[] {
  const products: Product[] = [];
  let id = 1;

  brands.forEach((brand, brandIndex) => {
    const names = productNames[brand.name];
    const cats = categories[brand.name];
    
    names.forEach((name, i) => {
      const price = Math.floor(Math.random() * 200) + 60;
      const discount = Math.random() > 0.5 ? Math.floor(Math.random() * 30) + 10 : 0;
      const originalPrice = discount > 0 ? Math.floor(price / (1 - discount / 100)) : price;
      const imgIndex = (brandIndex * 4 + i) % shoeImages.length;
      
      products.push({
        id: `prod-${id}`,
        name,
        brand: brand.name,
        category: cats[i % cats.length],
        price,
        originalPrice,
        discount,
        rating: Math.round((3.5 + Math.random() * 1.5) * 10) / 10,
        reviews: Math.floor(Math.random() * 500) + 20,
        sizes: sizeOptions.slice(Math.floor(Math.random() * 3), Math.floor(Math.random() * 5) + 8),
        colors: colorOptions.slice(Math.floor(Math.random() * 2), Math.floor(Math.random() * 3) + 3),
        gender: ['men', 'women', 'unisex'][Math.floor(Math.random() * 3)] as 'men' | 'women' | 'unisex',
        image: shoeImages[imgIndex],
        images: [shoeImages[imgIndex], shoeImages[(imgIndex + 1) % shoeImages.length], shoeImages[(imgIndex + 2) % shoeImages.length]],
        description: `Premium ${brand.name} ${name} featuring advanced comfort technology, durable construction, and iconic design. Perfect for ${cats[i % cats.length].toLowerCase()} enthusiasts.`,
        isNew: i < 3,
        isSale: discount > 0,
      });
      id++;
    });
  });

  return products;
}

export const products = generateProducts();
