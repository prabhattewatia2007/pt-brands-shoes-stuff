import { Link } from 'react-router-dom';
import { Instagram, Twitter, Facebook, Youtube, Mail, MapPin, Phone } from 'lucide-react';
import { useState } from 'react';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 3000);
    }
  };

  return (
    <footer className="bg-[#0a0a0a] border-t border-[#1a1a1a]">
      {/* Newsletter */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-gradient-to-r from-orange-600/10 to-orange-500/5 border border-orange-500/20 rounded-2xl p-8 md:p-12 text-center mb-12">
          <h3 className="text-2xl md:text-3xl font-bold text-white mb-3">JOIN THE PT COMMUNITY</h3>
          <p className="text-gray-400 mb-6 max-w-md mx-auto">Get updates about new collections and exclusive offers.</p>
          <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1 bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
            />
            <button type="submit" className="btn-primary whitespace-nowrap">
              {subscribed ? '✓ Subscribed!' : 'SUBSCRIBE'}
            </button>
          </form>
        </div>

        {/* Footer Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-black text-sm">PT</span>
              </div>
              <span className="text-white font-bold tracking-wider text-sm">PT BRANDS</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-4">
              Your premium destination for branded footwear. Step into your style with the world's most popular brands.
            </p>
            <div className="flex space-x-3">
              <a href="#" className="w-9 h-9 bg-[#1a1a1a] rounded-lg flex items-center justify-center text-gray-400 hover:text-orange-500 hover:bg-[#222] transition-all">
                <Instagram size={16} />
              </a>
              <a href="#" className="w-9 h-9 bg-[#1a1a1a] rounded-lg flex items-center justify-center text-gray-400 hover:text-orange-500 hover:bg-[#222] transition-all">
                <Twitter size={16} />
              </a>
              <a href="#" className="w-9 h-9 bg-[#1a1a1a] rounded-lg flex items-center justify-center text-gray-400 hover:text-orange-500 hover:bg-[#222] transition-all">
                <Facebook size={16} />
              </a>
              <a href="#" className="w-9 h-9 bg-[#1a1a1a] rounded-lg flex items-center justify-center text-gray-400 hover:text-orange-500 hover:bg-[#222] transition-all">
                <Youtube size={16} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">SHOP</h4>
            <ul className="space-y-2">
              {["Men's Shoes", "Women's Shoes", "Running", "Sneakers", "New Arrivals", "Sale"].map(item => (
                <li key={item}>
                  <Link to="/products" className="text-gray-400 hover:text-orange-500 text-sm transition-colors">{item}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">BRANDS</h4>
            <ul className="space-y-2">
              {['Nike', 'Adidas', 'Puma', 'New Balance', 'ASICS', 'Converse'].map(brand => (
                <li key={brand}>
                  <Link to={`/brands/${brand.toLowerCase().replace(' ', '-')}`} className="text-gray-400 hover:text-orange-500 text-sm transition-colors">{brand}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">CONTACT</h4>
            <ul className="space-y-3">
              <li className="flex items-center space-x-2 text-gray-400 text-sm">
                <MapPin size={14} className="text-orange-500" />
                <span>123 Fashion Street, NY 10001</span>
              </li>
              <li className="flex items-center space-x-2 text-gray-400 text-sm">
                <Phone size={14} className="text-orange-500" />
                <span>+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center space-x-2 text-gray-400 text-sm">
                <Mail size={14} className="text-orange-500" />
                <span>support@ptbrands.com</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-[#1a1a1a] pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-sm">© 2024 PT Brands Shoes Stuff. All rights reserved.</p>
          <div className="flex space-x-6">
            <Link to="/privacy" className="text-gray-500 hover:text-gray-300 text-sm transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="text-gray-500 hover:text-gray-300 text-sm transition-colors">Terms & Conditions</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
