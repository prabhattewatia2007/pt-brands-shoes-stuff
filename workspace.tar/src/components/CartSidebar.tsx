import { X, Plus, Minus, ShoppingBag, Trash2 } from 'lucide-react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { removeFromCart, updateQuantity, toggleCart } from '../store/cartSlice';
import { Link } from 'react-router-dom';

export default function CartSidebar() {
  const dispatch = useDispatch();
  const { items, isOpen } = useSelector((state: RootState) => state.cart);
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100]">
      {/* Overlay */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={() => dispatch(toggleCart())}
      />
      
      {/* Sidebar */}
      <div className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-[#0a0a0a] border-l border-[#222] flex flex-col animate-slide-in">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#222]">
          <div className="flex items-center gap-2">
            <ShoppingBag size={20} className="text-orange-500" />
            <h2 className="text-white font-bold text-lg">Your Cart ({items.length})</h2>
          </div>
          <button
            onClick={() => dispatch(toggleCart())}
            className="p-2 text-gray-400 hover:text-white transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <ShoppingBag size={48} className="text-gray-600 mb-4" />
              <p className="text-gray-400 font-medium">Your cart is empty</p>
              <p className="text-gray-600 text-sm mt-1">Add some items to get started</p>
              <button
                onClick={() => dispatch(toggleCart())}
                className="mt-4 btn-primary text-sm"
              >
                Continue Shopping
              </button>
            </div>
          ) : (
            items.map(item => (
              <div key={item.id} className="flex gap-3 bg-[#141414] rounded-xl p-3 border border-[#222]">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-20 h-20 object-cover rounded-lg"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-orange-500 text-[10px] font-semibold uppercase">{item.brand}</p>
                  <p className="text-white text-sm font-medium truncate">{item.name}</p>
                  <p className="text-gray-500 text-xs mt-0.5">Size: {item.size} | {item.color}</p>
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => dispatch(updateQuantity({ id: item.id, quantity: Math.max(1, item.quantity - 1) }))}
                        className="w-6 h-6 bg-[#222] rounded flex items-center justify-center text-gray-400 hover:text-white"
                      >
                        <Minus size={12} />
                      </button>
                      <span className="text-white text-sm font-medium">{item.quantity}</span>
                      <button
                        onClick={() => dispatch(updateQuantity({ id: item.id, quantity: item.quantity + 1 }))}
                        className="w-6 h-6 bg-[#222] rounded flex items-center justify-center text-gray-400 hover:text-white"
                      >
                        <Plus size={12} />
                      </button>
                    </div>
                    <span className="text-white font-bold text-sm">${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                </div>
                <button
                  onClick={() => dispatch(removeFromCart(item.id))}
                  className="self-start p-1 text-gray-500 hover:text-red-500 transition-colors"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="border-t border-[#222] p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Subtotal</span>
              <span className="text-white font-bold text-lg">${total.toFixed(2)}</span>
            </div>
            <p className="text-gray-500 text-xs">Shipping and taxes calculated at checkout</p>
            <Link
              to="/checkout"
              onClick={() => dispatch(toggleCart())}
              className="block w-full btn-primary text-center"
            >
              Proceed to Checkout
            </Link>
            <button
              onClick={() => dispatch(toggleCart())}
              className="block w-full text-center text-gray-400 hover:text-white text-sm py-2 transition-colors"
            >
              Continue Shopping
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
