import { Link } from 'react-router-dom';
import { Heart, ShoppingBag, Star, Eye } from 'lucide-react';
import { Product } from '../data/products';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../store';
import { toggleWishlist } from '../store/wishlistSlice';
import { addToCart } from '../store/cartSlice';
import { useState } from 'react';

interface Props {
  product: Product;
  index?: number;
}

export default function ProductCard({ product, index = 0 }: Props) {
  const dispatch = useDispatch();
  const wishlistItems = useSelector((state: RootState) => state.wishlist.items);
  const isInWishlist = wishlistItems.some(item => item.id === product.id);
  const [addedToCart, setAddedToCart] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dispatch(addToCart({
      productId: product.id,
      name: product.name,
      brand: product.brand,
      price: product.price,
      image: product.image,
      size: product.sizes[Math.floor(product.sizes.length / 2)],
      color: product.colors[0],
      quantity: 1,
    }));
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 1500);
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dispatch(toggleWishlist(product));
  };

  return (
    <div
      className="group relative bg-[#141414] rounded-2xl overflow-hidden card-hover border border-[#222] hover:border-orange-500/30"
      style={{ animationDelay: `${index * 0.1}s` }}
    >
      <Link to={`/product/${product.id}`} className="block">
        {/* Image */}
        <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-[#1a1a1a] to-[#0f0f0f]">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover product-image-zoom"
            loading="lazy"
          />
          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-2">
            {product.isNew && (
              <span className="bg-green-500 text-white text-[10px] font-bold px-2 py-1 rounded-md">NEW</span>
            )}
            {product.isSale && (
              <span className="bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-md">-{product.discount}%</span>
            )}
          </div>
          {/* Quick Actions */}
          <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button
              onClick={handleWishlist}
              className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                isInWishlist ? 'bg-red-500 text-white' : 'bg-white/90 text-gray-800 hover:bg-red-500 hover:text-white'
              }`}
            >
              <Heart size={14} fill={isInWishlist ? 'currentColor' : 'none'} />
            </button>
            <button className="w-8 h-8 bg-white/90 rounded-full flex items-center justify-center text-gray-800 hover:bg-orange-500 hover:text-white transition-all">
              <Eye size={14} />
            </button>
          </div>
        </div>

        {/* Info */}
        <div className="p-4">
          <p className="text-orange-500 text-xs font-semibold uppercase tracking-wider mb-1">{product.brand}</p>
          <h3 className="text-white font-medium text-sm mb-2 truncate group-hover:text-orange-400 transition-colors">
            {product.name}
          </h3>
          <div className="flex items-center gap-1 mb-2">
            <Star size={12} className="text-yellow-400 fill-yellow-400" />
            <span className="text-gray-400 text-xs">{product.rating}</span>
            <span className="text-gray-600 text-xs">({product.reviews})</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-white font-bold">${product.price}</span>
              {product.discount > 0 && (
                <span className="text-gray-500 text-sm line-through">${product.originalPrice}</span>
              )}
            </div>
          </div>
        </div>
      </Link>

      {/* Add to Cart Button */}
      <div className="px-4 pb-4">
        <button
          onClick={handleAddToCart}
          className={`w-full py-2.5 rounded-lg text-sm font-medium flex items-center justify-center gap-2 transition-all ${
            addedToCart
              ? 'bg-green-500 text-white'
              : 'bg-[#1f1f1f] text-gray-300 hover:bg-orange-500 hover:text-white border border-[#333] hover:border-orange-500'
          }`}
        >
          <ShoppingBag size={14} />
          {addedToCart ? 'Added!' : 'Add to Cart'}
        </button>
      </div>
    </div>
  );
}
